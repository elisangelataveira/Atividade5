package br.com.sd.agencia.rs.ui;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import br.com.sd.agencia.rs.dtos.ResultadoDTO;
import br.com.sd.agencia.rs.dtos.hotelDTO;


public class Main {

	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
		WebTarget target =
				client.target("http://localhost:8080/sd-agencia-rs/rest").path("somador/SIM/SA� LUIS/PIAUI/22-22-2222/22-22-2222/"
						+ "1/45/6635534/0/");
		Invocation.Builder invocador = target.request(MediaType.APPLICATION_JSON);
		ResultadoDTO resultado = invocador.get(ResultadoDTO.class);
		//System.out.println(resultado.getResultado());
		System.out.println(resultado.getIda());
		System.out.println(resultado.getOrigem());
		System.out.println(resultado.getDestino());
		System.out.println(resultado.getData_Ida());
		System.out.println(resultado.getData_Volta());
		System.out.println(resultado.getNumero_Pessoas());
		System.out.println(resultado.getIdade());
		System.out.println(resultado.getCartao());
		System.out.println(resultado.getParcela());
		System.out.println("//////////////////////////////////////////////////////////////////////");
		Client hotel = ClientBuilder.newClient();
		WebTarget target2 =
				hotel.target("http://localhost:8080/sd-agencia-rs/rest").path("hotel/Intrigar/22-02-2022/23-02-2022/1/1/45/6635534/0/");
		Invocation.Builder invocadorH = target2.request(MediaType.APPLICATION_JSON);
		hotelDTO marcar = invocadorH.get(hotelDTO.class);
		System.out.println(marcar.getHotel());
		System.out.println(marcar.getData_Entrada());
		System.out.println(marcar.getData_Saida());
		System.out.println(marcar.getNumero_Pessoas());
		System.out.println(marcar.getNumero_Quartos());
		System.out.println(marcar.getIdade());
		System.out.println(marcar.getCartao());
		System.out.println(marcar.getParcela());
		
		
	}

}

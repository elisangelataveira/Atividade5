package br.com.sd.agencia.rs.dtos;

public class hotelDTO {
	
	private String Hotel;
	private String Data_Entrada;
	private String Data_Saida;
	private int Numero_Quartos;
	private int idade;
	private int Numero_Pessoas;
	private int cartao;
	private int parcela;
	
	public String getHotel() {
		return Hotel;
	}
	public void setHotel(String hotel) {
		Hotel = hotel;
	}
	public String getData_Entrada() {
		return Data_Entrada;
	}
	public void setData_Entrada(String data_Entrada) {
		Data_Entrada = data_Entrada;
	}
	public String getData_Saida() {
		return Data_Saida;
	}
	public void setData_Saida(String data_Saida) {
		Data_Saida = data_Saida;
	}
	public int getNumero_Quartos() {
		return Numero_Quartos;
	}
	public void setNumero_Quartos(int numero_Quartos) {
		Numero_Quartos = numero_Quartos;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public int getNumero_Pessoas() {
		return Numero_Pessoas;
	}
	public void setNumero_Pessoas(int numero_Pessoas) {
		Numero_Pessoas = numero_Pessoas;
	}
	public int getCartao() {
		return cartao;
	}
	public void setCartao(int cartao) {
		this.cartao = cartao;
	}
	public int getParcela() {
		return parcela;
	}
	public void setParcela(int parcela) {
		this.parcela = parcela;
	}
	
	
	
	

}

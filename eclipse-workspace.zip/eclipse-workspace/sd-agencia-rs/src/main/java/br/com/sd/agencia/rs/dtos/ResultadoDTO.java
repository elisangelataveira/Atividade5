package br.com.sd.agencia.rs.dtos;

public class ResultadoDTO {
	private String Ida;
	private String Origem;
	private String Destino;
	private String Data_Ida;
	private String Data_Volta;
	private String idade;
	private String Numero_Pessoas;
	private String cartao;
	private String parcela;
	private int resultado;

	public int getResultado() {
		return resultado;
	}

	public void setResultado(int resultado) {
		this.resultado = resultado;
	}

	public String getIda() {
		return Ida;
	}

	public void setIda(String ida) {
		Ida = ida;
	}

	public String getOrigem() {
		return Origem;
	}

	public void setOrigem(String origem) {
		Origem = origem;
	}

	public String getDestino() {
		return Destino;
	}

	public void setDestino(String destino) {
		Destino = destino;
	}

	public String getData_Ida() {
		return Data_Ida;
	}

	public void setData_Ida(String data_Ida) {
		Data_Ida = data_Ida;
	}

	public String getData_Volta() {
		return Data_Volta;
	}

	public void setData_Volta(String data_Volta) {
		Data_Volta = data_Volta;
	}

	public String getIdade() {
		return idade;
	}

	public void setIdade(String idade) {
		this.idade = idade;
	}

	public String getNumero_Pessoas() {
		return Numero_Pessoas;
	}

	public void setNumero_Pessoas(String numero_Pessoas) {
		Numero_Pessoas = numero_Pessoas;
	}

	public String getCartao() {
		return cartao;
	}

	public void setCartao(String cartao) {
		this.cartao = cartao;
	}

	public String getParcela() {
		return parcela;
	}

	public void setParcela(String parcela) {
		this.parcela = parcela;
	}
	
	

}

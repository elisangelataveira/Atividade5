package br.com.sd.agencia.rs.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.sd.agencia.rs.dtos.ResultadoDTO;

@Path("/somador")
public class SomadorController {
	
	@GET 
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Path("{ida}/{origem}/{destino}/{dataida}/{datavolta}/{pessoa}/{idadepessoa}/{cartao}/{parcela}")
	public Response somar(@PathParam("ida") String ida,@PathParam("origem") String origem,
			@PathParam("destino") String destino,@PathParam("dataida")  String dataida,
			@PathParam("datavolta") String datavolta ,@PathParam("pessoa")  String pessoa,@PathParam("idadepessoa")  String idadepessoa,
			@PathParam("cartao")  String cartao ,@PathParam("parcela")  String parcela){
		
		ResultadoDTO resultado = new ResultadoDTO();
		resultado.setIda(ida);
		resultado.setOrigem(origem);
		resultado.setDestino(destino);
		resultado.setData_Ida(ida);
		resultado.setData_Volta(datavolta);
		resultado.setIdade(idadepessoa);
		resultado.setNumero_Pessoas(pessoa);
		resultado.setCartao(cartao);
		resultado.setParcela(parcela);
		
		return Response.status(200).entity(resultado).build();
		
	}

}

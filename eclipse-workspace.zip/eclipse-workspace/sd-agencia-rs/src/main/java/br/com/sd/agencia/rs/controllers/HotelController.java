package br.com.sd.agencia.rs.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.sd.agencia.rs.dtos.hotelDTO;

@Path("/hotel")
public class HotelController {
	@GET 
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@Path("{hotel}/{entrada}/{saida}/{quarto}/{idade}/{pessoa}/{cartao}/{parcela}")
	public Response somar(@PathParam("hotel") String hotel,@PathParam("entrada") String entrada,
							@PathParam("saida") String saida,@PathParam("quarto") int quarto,
							@PathParam("idade") int idade ,@PathParam("pessoa") int pessoa,
							@PathParam("cartao") int cartao ,@PathParam("parcela") int parcela){
		hotelDTO marca = new hotelDTO();
		marca.setHotel(hotel);
		marca.setData_Entrada(entrada);
		marca.setData_Saida(saida);
		marca.setNumero_Quartos(quarto);
		marca.setIdade(idade);
		marca.setNumero_Pessoas(pessoa);
		marca.setCartao(cartao);
		marca.setParcela(parcela);
		return Response.status(200).entity(marca).build();
		
	}

}

package br.com.sd.agencia.rs.config;

import org.glassfish.jersey.server.ResourceConfig;

import br.com.sd.agencia.rs.controllers.HotelController;
import br.com.sd.agencia.rs.controllers.SomadorController;

public class AppConfig extends ResourceConfig {
	
	public AppConfig() {
		register(SomadorController.class);
		register(HotelController.class);
	}

}
